package it.unisalento.pps1920.carsharing.model;

public class Cliente {

    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
