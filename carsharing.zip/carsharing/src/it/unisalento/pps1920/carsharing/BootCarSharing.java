package it.unisalento.pps1920.carsharing;

import it.unisalento.pps1920.carsharing.dao.interfaces.ILocalitaDAO;
import it.unisalento.pps1920.carsharing.dao.interfaces.IPrenotazioneDAO;
import it.unisalento.pps1920.carsharing.dao.mysql.LocalitaDAO;
import it.unisalento.pps1920.carsharing.dao.mysql.PrenotazioneDAO;
import it.unisalento.pps1920.carsharing.model.Localita;
import it.unisalento.pps1920.carsharing.model.Prenotazione;

import java.util.ArrayList;

public class BootCarSharing {

    public static void main(String args[]) {

        ILocalitaDAO lDao = new LocalitaDAO();

        System.out.println("CHIAMO METODO findAll");
        for(Localita loc : lDao.findAll()) {
            System.out.println("ID: "+loc.getId());
            System.out.println("Nome: "+loc.getCitta());
            System.out.println("Lat: "+loc.getLatitudine());
            System.out.println("Lon: "+loc.getLongitudine());
            System.out.println("--------------");
        }

        System.out.println("CHIAMO METODO findById");
        Localita loc = lDao.findById(1);
        if(loc!=null) {
            System.out.println("ID: " + loc.getId());
            System.out.println("Nome: " + loc.getCitta());
            System.out.println("Lat: " + loc.getLatitudine());
            System.out.println("Lon: " + loc.getLongitudine());
            System.out.println("--------------");
        }

        IPrenotazioneDAO pDao = new PrenotazioneDAO();
        ArrayList<Prenotazione> lista = pDao.findAll();

        for(Prenotazione p : lista) {
            System.out.println("ID CLIENTE: "+p.getCliente().getId());
            System.out.println("AUTO "+p.getMezzo().getModello().getNome()+" TARGATA "+p.getMezzo().getTarga());
            System.out.println("STAZIONE DI PARTENZA: "+p.getPartenza().getNome());
            System.out.println("STAZIONE DI ARRIVO: "+p.getArrivo().getNome());
            System.out.println("POSTI OCCUPATI: "+p.getNumPostiOccupati());
        }

    }

}
