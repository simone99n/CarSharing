package it.unisalento.pps1920.carsharing.dao.interfaces;

import it.unisalento.pps1920.carsharing.model.Modello;

public interface IModelloDAO extends IBaseDAO<Modello> {
}
