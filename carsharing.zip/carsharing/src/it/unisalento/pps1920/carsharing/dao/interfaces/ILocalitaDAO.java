package it.unisalento.pps1920.carsharing.dao.interfaces;

import it.unisalento.pps1920.carsharing.model.Localita;

public interface ILocalitaDAO extends IBaseDAO<Localita> {
}
