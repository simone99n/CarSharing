package it.unisalento.pps1920.carsharing.dao.mysql;

import it.unisalento.pps1920.carsharing.DbConnection;
import it.unisalento.pps1920.carsharing.dao.interfaces.IStazioneDAO;
import it.unisalento.pps1920.carsharing.model.Stazione;

import java.util.ArrayList;

public class StazioneDAO implements IStazioneDAO {
    @Override
    public Stazione findById(int id) {
        Stazione s = null;

        ArrayList<String[]> res = DbConnection.getInstance().eseguiQuery("SELECT * FROM stazione WHERE idstazione = "+id+";");

        if(res.size() == 1 ) {
            String riga[] = res.get(0);
            s=new Stazione();
            s.setId(Integer.parseInt(riga[0]));
            s.setNome(riga[1]);
            s.setLatitudine(Double.parseDouble(riga[2]));
            s.setLongitudine(Double.parseDouble(riga[3]));
        }

        return s;
    }

    @Override
    public ArrayList<Stazione> findAll() {
        return null;
    }
}
