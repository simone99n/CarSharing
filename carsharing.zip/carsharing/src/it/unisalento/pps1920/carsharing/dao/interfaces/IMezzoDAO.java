package it.unisalento.pps1920.carsharing.dao.interfaces;

import it.unisalento.pps1920.carsharing.model.Mezzo;

public interface IMezzoDAO extends IBaseDAO<Mezzo> {
}
